@extends('layouts.website')
@section('content')
    <comparison />
@endsection
