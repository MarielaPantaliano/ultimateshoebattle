@extends('layouts.website')
@section('content')
    <stats />
@endsection
