@extends('layouts.website')
@section('content')
    <landing />
@endsection
