@extends('layouts.website')
@section('content')
    <most-searched />
@endsection
